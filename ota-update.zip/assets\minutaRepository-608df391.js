import{s as n}from"./index-104934cd.js";async function _(){const{data:e,error:t}=await n.from("minutas").select(`
      *,
      profiles:created_by ( id, name, email ),
      minuta_items ( id, status )
    `).order("created_at",{ascending:!1});return t?(console.error("[minutaRepo] Error fetching minutas:",t),[]):e||[]}async function w(e){const{data:t,error:r}=await n.from("minutas").select(`
      *,
      creator:created_by ( id, name, email ),
      minuta_items (
        *,
        assignee:assigned_to ( id, name, email ),
        approver:approved_by ( id, name, email )
      )
    `).eq("id",e).single();return r?(console.error("[minutaRepo] Error fetching minuta:",r),null):t}async function v({title:e,description:t,created_by:r}){const{data:a,error:o}=await n.from("minutas").insert({title:e,description:t,created_by:r,status:"activa"}).select().single();if(o)throw console.error("[minutaRepo] Error creating minuta:",o),o;return a}async function f(e,t){const{data:r,error:a}=await n.from("minutas").update({...t,updated_at:new Date().toISOString()}).eq("id",e).select().single();if(a)throw console.error("[minutaRepo] Error updating minuta:",a),a;return r}async function y(e){return f(e,{status:"cerrada"})}async function h({minuta_id:e,assigned_to:t,title:r,description:a,due_date:o}){const{data:i,error:s}=await n.from("minuta_items").insert({minuta_id:e,assigned_to:t,title:r,description:a,due_date:o,status:"pendiente"}).select(`
      *,
      assignee:assigned_to ( id, name, email )
    `).single();if(s)throw console.error("[minutaRepo] Error creating item:",s),s;return i}async function E(e){const{data:t,error:r}=await n.from("minuta_items").select(`
      *,
      minuta:minuta_id ( id, title, status ),
      approver:approved_by ( id, name, email )
    `).eq("assigned_to",e).order("created_at",{ascending:!1});return r?(console.error("[minutaRepo] Error fetching my items:",r),[]):t||[]}async function R(e,t,r=null){const a={status:t,updated_at:new Date().toISOString()};r!==null&&(a.evidence_notes=r);const{data:o,error:i}=await n.from("minuta_items").update(a).eq("id",e).select().single();if(i)throw console.error("[minutaRepo] Error updating item status:",i),i;return o}async function S(e,t){var m;const r=((m=t.name)==null?void 0:m.split(".").pop())||"jpg",a=`${e}/${Date.now()}.${r}`,{data:o,error:i}=await n.storage.from("minuta-evidence").upload(a,t,{cacheControl:"3600",upsert:!1});if(i)throw console.error("[minutaRepo] Error uploading evidence:",i),i;const{data:s}=n.storage.from("minuta-evidence").getPublicUrl(a),d=s==null?void 0:s.publicUrl,{data:u}=await n.from("minuta_items").select("evidence_urls").eq("id",e).single(),l=[...(u==null?void 0:u.evidence_urls)||[],d],{data:p,error:c}=await n.from("minuta_items").update({evidence_urls:l,status:"evidencia_enviada",updated_at:new Date().toISOString()}).eq("id",e).select().single();if(c)throw console.error("[minutaRepo] Error updating evidence URLs:",c),c;return{...p,newUrl:d}}async function b(e,t){const{data:r,error:a}=await n.from("minuta_items").update({status:"aprobada",approved_by:t,approved_at:new Date().toISOString(),rejection_reason:null,updated_at:new Date().toISOString()}).eq("id",e).select().single();if(a)throw console.error("[minutaRepo] Error approving item:",a),a;return r}async function I(e,t){const{data:r,error:a}=await n.from("minuta_items").update({status:"rechazada",rejection_reason:t,approved_by:null,approved_at:null,updated_at:new Date().toISOString()}).eq("id",e).select().single();if(a)throw console.error("[minutaRepo] Error rejecting item:",a),a;return r}async function M(e){const{error:t}=await n.from("minuta_items").delete().eq("id",e);if(t)throw console.error("[minutaRepo] Error deleting item:",t),t}export{h as a,y as b,v as c,E as d,R as e,w as f,_ as g,b as h,M as i,I as r,S as u};
