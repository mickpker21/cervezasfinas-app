import{dc as n}from"./index-104934cd.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
