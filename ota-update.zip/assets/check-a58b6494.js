import{Z as e}from"./index-0daedfce.js";const o=e("Check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]);export{o as C};
