import{Z as o}from"./index-0daedfce.js";const t=o("Bluetooth",[["path",{d:"m7 7 10 10-5 5V2l5 5L7 17",key:"1q5490"}]]);export{t as B};
