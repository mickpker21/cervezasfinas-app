import{cA as r}from"./index-0daedfce.js";function n(n,o,s){return r(n,-o,s)}export{n as s};
