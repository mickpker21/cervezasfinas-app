import{Z as s}from"./index-0daedfce.js";const a=s("Minus",[["path",{d:"M5 12h14",key:"1ays0h"}]]);export{a as M};
