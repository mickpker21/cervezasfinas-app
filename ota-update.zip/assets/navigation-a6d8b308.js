import{Z as o}from"./index-0daedfce.js";const t=o("Navigation",[["polygon",{points:"3 11 22 2 13 21 11 13 3 11",key:"1ltx0t"}]]);export{t as N};
