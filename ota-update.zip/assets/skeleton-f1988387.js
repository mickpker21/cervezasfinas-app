import{j as a,aS as s}from"./index-0daedfce.js";function e({className:e,...r}){return a.jsx("div",{className:s("animate-pulse rounded-md bg-gray-700/50",e),...r})}export{e as S};
