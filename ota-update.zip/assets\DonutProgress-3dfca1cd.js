import{j as t}from"./index-104934cd.js";import{C as l,b as n}from"./styles-3a2bb691.js";function m({value:r,text:i,color:o="#22c55e",textSize:s="1.6em",onClick:e}){return t.jsxs("div",{style:{width:"100%",height:"100%",minWidth:0,minHeight:0,cursor:e?"pointer":"default",display:"flex",alignItems:"center",justifyContent:"center",textAlign:"center"},onClick:e,children:[t.jsx(l,{value:r,text:i,styles:n({pathColor:o,textColor:"#fff",trailColor:"#222",backgroundColor:"#222",textSize:s})}),t.jsx("style",{children:`
        .CircularProgressbar-text {
          dominant-baseline: middle;
          text-anchor: middle;
          font-weight: bold;
        }
      `})]})}export{m as D};
