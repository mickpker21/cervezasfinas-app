import{ca as n}from"./index-104934cd.js";function a(o,s,t){return n(o,-s,t)}export{a as s};
