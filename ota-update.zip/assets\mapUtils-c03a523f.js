import{L as p}from"./leaflet-src-0649b7f5.js";const x=function(n){const i=n.getChildCount();let r="small";return i>10&&(r="medium"),i>100&&(r="large"),p.divIcon({html:`<div><span>${i}</span></div>`,className:`marker-cluster-custom marker-cluster-${r}`,iconSize:p.point(40,40,!0)})},d={competencia:"#2563eb",exclusivo:"#16a34a",mixto:"#eab308"},g="#6b7280",c=new Map;function b(n){return n?n instanceof Set?n:Array.isArray(n)?new Set(n.map(String)):null:null}function m(n,i,r){if(!n)return!1;if(n.no_sales_with_asset||n.flag_no_sales)return!0;const t=n.client_code??n.codigo??null;if(t&&(i!=null&&i.has(String(t))))return!0;const e=n.id??n.clientId??n.client_id??null;return!!(e&&(r!=null&&r.has(String(e))))}function y(n,i,r=!1,t=null){const e=String(n||"").trim().toLowerCase(),o=t||d[e]||g;let s=i==null?"":String(i).trim();s.length>3&&(s=s.slice(0,3));const l=`dot:${o}:${s}:${r?"F":"-"}`;if(c.has(l))return c.get(l);const u=`
  <span style="
    position:relative;
    display:grid;place-items:center;
    width:32px;height:32px;border-radius:50%;
    background:linear-gradient(135deg, ${o} 0%, ${o}dd 100%);
    border:3px solid #fff;
    box-shadow:0 4px 12px rgba(0,0,0,.25), 0 2px 6px rgba(0,0,0,.15), inset 0 1px 0 rgba(255,255,255,.3);
    color:#fff;font-weight:800;font-size:11px;line-height:1;
    text-shadow:0 1px 3px rgba(0,0,0,.5);
    transition: transform 0.2s ease;
    cursor: pointer;
  ">
    <span style="position:relative;z-index:2;">${s||""}</span>
    ${r?`<span title="Sin venta este mes con equipo" style="
      position:absolute; top:-8px; right:-8px;
      width:20px;height:20px;
      background:linear-gradient(135deg, #ef4444, #dc2626);
      border:2px solid #fff;
      border-radius:50%;
      display:flex;align-items:center;justify-content:center;
      font-size:11px; line-height:1;
      box-shadow:0 2px 8px rgba(239,68,68,0.4);
      z-index:3;
    ">🚩</span>`:""}
    <span style="
      position:absolute;
      inset:0;
      border-radius:50%;
      background:radial-gradient(circle at 30% 30%, rgba(255,255,255,0.3), transparent 60%);
      pointer-events:none;
    "></span>
  </span>`,a=p.divIcon({className:"bg-transparent border-none cmp-marker-dot-premium",html:u.trim(),iconSize:[32,32],iconAnchor:[16,16],popupAnchor:[0,-18]});return c.set(l,a),a}function $(n){return n==null?"":n<950?`${Math.round(n)} m`:`${(n/1e3).toFixed(1)} km`}function _(n,i){const r=e=>{if(typeof e=="number")return Number.isFinite(e)?e:null;if(typeof e=="string"){const o=parseFloat(e);return Number.isFinite(o)?o:null}return null};let t=n;if(typeof t=="string")try{const e=JSON.parse(t);e&&(t=e)}catch{const o=t.includes(",")?",":t.includes(";")?";":null;if(o){const[s,l]=t.split(o).map(f=>f.trim()),u=r(s),a=r(l);if(u!=null&&a!=null)return{lat:u,lng:a}}}if(Array.isArray(t)&&t.length>=2){const e=r(t[0]),o=r(t[1]);if(e!=null&&o!=null)return{lat:e,lng:o}}if(t&&typeof t=="object"){const e=r(t.lat??t.latitude??t.latitud??t.Lat),o=r(t.lng??t.longitude??t.longitud??t.Lng);if(e!=null&&o!=null)return{lat:e,lng:o}}if(i&&typeof i=="object"){const e=r(i.lat??i.latitude??i.latitud),o=r(i.lng??i.longitude??i.longitud);if(e!=null&&o!=null)return{lat:e,lng:o}}return null}export{x as c,y as g,$ as h,m as i,_ as n,b as t};
