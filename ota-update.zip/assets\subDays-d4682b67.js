import{bZ as o}from"./index-104934cd.js";function n(s,a,r){return o(s,-a,r)}export{n as s};
