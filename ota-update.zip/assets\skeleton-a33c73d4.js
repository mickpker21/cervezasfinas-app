import{j as s,aw as n}from"./index-104934cd.js";function t({className:a,...e}){return s.jsx("div",{className:n("animate-pulse rounded-md bg-gray-700/50",a),...e})}export{t as S};
