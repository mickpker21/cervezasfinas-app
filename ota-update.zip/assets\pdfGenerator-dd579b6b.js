import A from"./html2canvas.esm-e0a7d97b.js";import{E as C}from"./jspdf.es.min-7a20ef11.js";import{a3 as g,_ as f,C as O}from"./index-104934cd.js";import{f as T}from"./geolocation-c538c0dd.js";var n;(function(t){t.Documents="DOCUMENTS",t.Data="DATA",t.Library="LIBRARY",t.Cache="CACHE",t.External="EXTERNAL",t.ExternalStorage="EXTERNAL_STORAGE",t.ExternalCache="EXTERNAL_CACHE",t.LibraryNoCloud="LIBRARY_NO_CLOUD",t.Temporary="TEMPORARY"})(n||(n={}));var x;(function(t){t.UTF8="utf8",t.ASCII="ascii",t.UTF16="utf16"})(x||(x={}));const I=g("Filesystem",{web:()=>f(()=>import("./web-185913de.js"),["assets/web-185913de.js","assets/index-104934cd.js","assets/index-9d556deb.css","assets/html2canvas.esm-e0a7d97b.js","assets/jspdf.es.min-7a20ef11.js","assets/geolocation-c538c0dd.js"]).then(t=>new t.FilesystemWeb)});T();const R=g("Share",{web:()=>f(()=>import("./web-fdf2d762.js"),["assets/web-fdf2d762.js","assets/index-104934cd.js","assets/index-9d556deb.css"]).then(t=>new t.ShareWeb)});async function z(t){var a,c;try{console.log("Started generateClientPdf (Premium Dark)",t);let e=document.getElementById("pdf-gen-container");e&&document.body.removeChild(e),e=document.createElement("div"),e.id="pdf-gen-container",e.style.position="fixed",e.style.left="0",e.style.top="0",e.style.width="800px",e.style.minHeight="1123px",e.style.zIndex="-9999",e.style.backgroundColor="#ffffff",e.style.color="#000",e.style.fontFamily="Arial, sans-serif",document.body.appendChild(e);let b="Fecha";try{b=new Date().toLocaleDateString("es-MX",{year:"numeric",month:"long",day:"numeric",hour:"2-digit",minute:"2-digit"})}catch{}const i=o=>(t.visit_days||"").includes(o)?"X":"",l=o=>(t.visit_day_televenta||"").includes(o)?"X":"",d=o=>o??"",y="/logo3.png";e.innerHTML=`
          <div style="width: 800px; padding: 40px; background: white; color: black; font-family: Arial, sans-serif; box-sizing: border-box;">
            
            <!-- HEADER -->
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <div style="width: 45%;">
                    <img src="${y}?v=${Date.now()}" style="width: 550px; height: auto; object-fit: contain;" crossorigin="anonymous" />
                </div>
                <div style="width: 50%;">
                    <table style="width: 100%; border-collapse: collapse; font-size: 10px;">
                        <tr>
                            <td style="border: 1px solid black; padding: 4px; background: #e6ffe6; font-weight: bold; width: 45%; color: #004d00;">FECHA DE SOLICITUD:</td>
                            <td style="border: 1px solid black; padding: 4px;">${b}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid black; padding: 4px; background: #e6ffe6; font-weight: bold; color: #004d00;">RUTA DE CAPTACION:</td>
                            <td style="border: 1px solid black; padding: 4px;">${d(t.internal_route)}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid black; padding: 4px; background: #e6ffe6; font-weight: bold; color: #004d00;">RUTA DE VENTA:</td>
                            <td style="border: 1px solid black; padding: 4px;">${d(t.sales_route)}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid black; padding: 4px; background: #e6ffe6; font-weight: bold; color: #004d00;">RUTA DE REPARTO:</td>
                            <td style="border: 1px solid black; padding: 4px;">&nbsp;</td>
                        </tr>
                    </table>
                </div>
            </div>

            <!-- GENERALES -->
            <div style="background: #007f00; color: white; font-weight: bold; text-align: center; font-size: 11px; padding: 4px; margin-bottom: 5px; border-radius: 4px 4px 0 0;">GENERALES</div>
            
            <table style="width: 100%; border-collapse: collapse; font-size: 10px; margin-bottom: 15px;">
                <tr>
                    <td colspan="2" style="border: 1px solid black; padding: 5px;">
                        <div style="font-size: 8px; color: #007f00; font-weight: bold;">NOMBRE DEL ESTABLECIMIENTO:</div>
                        <div style="font-weight: bold; font-size: 12px; margin-top: 2px;">${d(t.business_name||t.businessName)}</div>
                    </td>
                    <td style="border: 1px solid black; padding: 5px;">
                        <div style="font-size: 8px; color: #007f00; font-weight: bold;">NO DE CLIENTE:</div>
                        <div style="margin-top: 2px;">${d(t.client_code)}</div>
                    </td>
                    <td style="border: 1px solid black; padding: 5px;">
                        <div style="font-size: 8px; color: #007f00; font-weight: bold;">NO DE PROVEEDOR:</div>
                        <div style="margin-top: 2px;">&nbsp;</div>
                    </td>
                </tr>
                <tr>
                    <td colspan="3" style="border: 1px solid black; padding: 5px;">
                        <div style="font-size: 8px; color: #007f00; font-weight: bold;">CALLE Y CALLE:</div>
                        <div style="margin-top: 2px;">${d(t.address)}</div>
                    </td>
                    <td style="border: 1px solid black; padding: 5px;">
                        <div style="font-size: 8px; color: #007f00; font-weight: bold;">COLONIA:</div>
                        <div style="margin-top: 2px;">${d(t.colony)}</div>
                    </td>
                </tr>
                <tr>
                    <td colspan="2" style="border: 1px solid black; padding: 5px;">
                        <div style="font-size: 8px; color: #007f00; font-weight: bold;">ENTRE CALLE:</div>
                         <div style="margin-top: 2px;">${d(t.cross_street)}</div>
                    </td>
                    <td style="border: 1px solid black; padding: 5px;">
                        <div style="font-size: 8px; color: #007f00; font-weight: bold;">NUMERO EXT:</div>
                        <div style="margin-top: 2px;">${d(t.exterior_number)}</div>
                    </td>
                     <td style="border: 1px solid black; padding: 5px;">
                        <div style="font-size: 8px; color: #007f00; font-weight: bold;">CP:</div>
                        <div style="margin-top: 2px;">${d(t.postal_code)}</div>
                    </td>
                </tr>
                 <tr>
                    <td style="border: 1px solid black; padding: 5px;">
                        <div style="font-size: 8px; color: #007f00; font-weight: bold;">NO INT:</div>
                        <div style="margin-top: 2px;">${d(t.interior_number)}</div>
                    </td>
                    <td colspan="3" style="border: 1px solid black; padding: 5px;">
                        <div style="font-size: 8px; color: #007f00; font-weight: bold;">REFERENCIAS:</div>
                        <div style="margin-top: 2px;">${d(t.reference||t.comments)}</div>
                    </td>
                </tr>
                <tr>
                    <td style="border: 1px solid black; padding: 5px;">
                        <div style="font-size: 8px; color: #007f00; font-weight: bold;">POBLACION:</div>
                        <div style="margin-top: 2px;">${d(t.city)}</div>
                    </td>
                    <td style="border: 1px solid black; padding: 5px;">
                        <div style="font-size: 8px; color: #007f00; font-weight: bold;">ESTADO:</div>
                         <div style="margin-top: 2px;">${d(t.state)}</div>
                    </td>
                    <td colspan="2" style="border: 1px solid black; padding: 5px;">
                        <div style="font-size: 8px; color: #007f00; font-weight: bold;">TELEFONO / EMAIL:</div>
                        <div style="margin-top: 2px;">${d(t.phone)} / ${d(t.email)}</div>
                    </td>
                </tr>
            </table>

            <!-- DATOS DE FACTURACION -->
            <div style="background: #007f00; color: white; font-weight: bold; text-align: center; font-size: 11px; padding: 4px; margin-bottom: 5px; border-radius: 4px 4px 0 0;">DATOS DE FACTURACION</div>
            <table style="width: 100%; border-collapse: collapse; font-size: 10px; margin-bottom: 15px;">
                <tr>
                     <td style="border: 1px solid black; padding: 5px; width: 30%;">
                        <div style="font-size: 8px; color: #007f00; font-weight: bold;">RFC:</div>
                        <div style="margin-top: 2px;">${d(t.rfc)}</div>
                    </td>
                    <td style="border: 1px solid black; padding: 5px;">
                        <div style="font-size: 8px; color: #007f00; font-weight: bold;">RAZON SOCIAL:</div>
                        <div style="font-weight: bold; margin-top: 2px;">${d(t.fiscal_name)}</div>
                    </td>
                </tr>
                 <tr>
                    <td colspan="2" style="border: 1px solid black; padding: 5px;">
                        <div style="font-size: 8px; color: #007f00; font-weight: bold;">DOMICILIO FISCAL:</div>
                        <div style="margin-top: 2px;">${d(t.fiscal_address)}</div>
                    </td>
                </tr>
                 <tr>
                    <td style="border: 1px solid black; padding: 5px;">
                        <div style="font-size: 8px; color: #007f00; font-weight: bold;">COLONIA O BARRIO:</div>
                        <div style="margin-top: 2px;">${d(t.fiscal_colony)}</div>
                    </td>
                     <td style="border: 1px solid black; padding: 5px;">
                        <div style="font-size: 8px; color: #007f00; font-weight: bold;">CP Y CEDULA IEPS:</div>
                        <div style="margin-top: 2px;">CP: ${d(t.fiscal_postal_code)} - IEPS: ${d(t.cedula_ieps)}</div>
                    </td>
                </tr>
            </table>

            <!-- CONTACTOS Y ROLES -->
            <div style="background: #007f00; color: white; font-weight: bold; text-align: center; font-size: 11px; padding: 4px; margin-bottom: 5px; border-radius: 4px 4px 0 0;">CONTACTOS Y ROLES</div>
             <table style="width: 100%; border-collapse: collapse; font-size: 10px; margin-bottom: 15px;">
                <tr>
                     <td style="border: 1px solid black; padding: 5px; width: 50%;">
                        <div style="font-size: 8px; color: #007f00; font-weight: bold;">DUEÑO:</div>
                        <div style="margin-top: 2px;">${d(t.name)}</div>
                    </td>
                    <td style="border: 1px solid black; padding: 5px;">
                        <div style="font-size: 8px; color: #007f00; font-weight: bold;">TELEFONO:</div>
                        <div style="margin-top: 2px;">${d(t.phone)}</div>
                    </td>
                </tr>
            </table>

            <!-- DATOS DE VENTA -->
             <div style="background: #007f00; color: white; font-weight: bold; text-align: center; font-size: 11px; padding: 4px; margin-bottom: 5px; border-radius: 4px 4px 0 0;">DATOS DE VENTA</div>
             <table style="width: 100%; border-collapse: collapse; font-size: 10px; margin-bottom: 15px;">
                <tr>
                    <td style="border: 1px solid black; padding: 5px; width: 20%;">
                        <div style="font-weight: bold; margin-bottom: 5px; font-size: 9px; color: #007f00;">MODALIDAD DE VENTA</div>
                         <div>${d(t.sales_modality)}</div>
                    </td>
                     <td style="border: 1px solid black; padding: 5px; width: 15%;">
                        <div style="font-weight: bold; margin-bottom: 5px; font-size: 9px; color: #007f00;">RITMO</div>
                         <div>${d(t.ritmo)}</div>
                    </td>
                    <td style="border: 1px solid black; padding: 2px; width: 65%;">
                        <table style="width: 100%; text-align: center; font-size: 8px; border-collapse: collapse;">
                            <tr style="background: #e6ffe6; color: #004d00; font-weight: bold;">
                                <td style="border: 1px solid #ccc; padding: 2px; width: 25%;">VISITAS</td>
                                <td style="border: 1px solid #ccc; padding: 2px;">L</td>
                                <td style="border: 1px solid #ccc; padding: 2px;">M</td>
                                <td style="border: 1px solid #ccc; padding: 2px;">M</td>
                                <td style="border: 1px solid #ccc; padding: 2px;">J</td>
                                <td style="border: 1px solid #ccc; padding: 2px;">V</td>
                                <td style="border: 1px solid #ccc; padding: 2px;">S</td>
                                <td style="border: 1px solid #ccc; padding: 2px;">D</td>
                            </tr>
                            <tr>
                                <td style="font-weight: bold; text-align: left; padding-left: 5px; border: 1px solid #ccc;">PRESENCIAL</td>
                                <td style="border: 1px solid #ccc;">${i("Lunes")}</td>
                                <td style="border: 1px solid #ccc;">${i("Martes")}</td>
                                <td style="border: 1px solid #ccc;">${i("Miércoles")}</td>
                                <td style="border: 1px solid #ccc;">${i("Jueves")}</td>
                                <td style="border: 1px solid #ccc;">${i("Viernes")}</td>
                                <td style="border: 1px solid #ccc;">${i("Sábado")}</td>
                                <td style="border: 1px solid #ccc;">${i("Domingo")}</td>
                            </tr>
                             <tr>
                                <td style="font-weight: bold; text-align: left; padding-left: 5px; border: 1px solid #ccc;">TELEVENTA</td>
                                <td style="border: 1px solid #ccc;">${l("Lunes")}</td>
                                <td style="border: 1px solid #ccc;">${l("Martes")}</td>
                                <td style="border: 1px solid #ccc;">${l("Miércoles")}</td>
                                <td style="border: 1px solid #ccc;">${l("Jueves")}</td>
                                <td style="border: 1px solid #ccc;">${l("Viernes")}</td>
                                <td style="border: 1px solid #ccc;">${l("Sábado")}</td>
                                <td style="border: 1px solid #ccc;">${l("Domingo")}</td>
                            </tr>
                             <tr>
                                <td style="font-weight: bold; text-align: left; padding-left: 5px; border: 1px solid #ccc;">REPARTO</td>
                                <td style="border: 1px solid #ccc;">&nbsp;</td>
                                <td style="border: 1px solid #ccc;">&nbsp;</td>
                                <td style="border: 1px solid #ccc;">&nbsp;</td>
                                <td style="border: 1px solid #ccc;">&nbsp;</td>
                                <td style="border: 1px solid #ccc;">&nbsp;</td>
                                <td style="border: 1px solid #ccc;">&nbsp;</td>
                                <td style="border: 1px solid #ccc;">&nbsp;</td>
                            </tr>
                        </table>
                    </td>
                </tr>
             </table>

             <!-- CANAL Y SEGMENTO -->
             <div style="background: #007f00; color: white; font-weight: bold; text-align: center; font-size: 11px; padding: 4px; margin-bottom: 5px; border-radius: 4px 4px 0 0;">CLASIFICACION Y CANAL</div>
             <table style="width: 100%; border-collapse: collapse; font-size: 10px; margin-bottom: 25px;">
                <tr>
                    <td style="border: 1px solid black; padding: 5px;">
                        <span style="font-weight: bold; color: #007f00;">TIPO CLIENTE:</span> ${d(t.client_type||t.type).toUpperCase()}
                    </td>
                     <td style="border: 1px solid black; padding: 5px;">
                        <span style="font-weight: bold; color: #007f00;">NIVEL (GEC):</span> ${d(t.level||t.gec)}
                    </td>
                     <td style="border: 1px solid black; padding: 5px;">
                        <span style="font-weight: bold; color: #007f00;">COORDENADAS:</span> ${d((a=t.coords)==null?void 0:a.lat)}, ${d((c=t.coords)==null?void 0:c.lng)}
                    </td>
                </tr>
             </table>

             <!-- FIRMAS -->
             <div style="background: #007f00; color: white; font-weight: bold; text-align: center; font-size: 11px; padding: 4px; margin-bottom: 5px; border-radius: 4px 4px 0 0;">FIRMAS AUTORIZADAS</div>
             <table style="width: 100%; border-collapse: collapse; font-size: 10px; text-align: center;">
                <tr>
                    <td style="border: 1px solid black; height: 80px; vertical-align: bottom; width: 33%;">
                        _______________________<br>
                        <span style="font-size: 8px;">SOLICITANTE</span>
                    </td>
                    <td style="border: 1px solid black; height: 80px; vertical-align: bottom; width: 33%;">
                        _______________________<br>
                        <span style="font-size: 8px;">AUTORIZA</span>
                    </td>
                    <td style="border: 1px solid black; height: 80px; vertical-align: bottom; width: 33%;">
                        _______________________<br>
                        <span style="font-size: 8px;">SUPERVISOR DE LOG. PRIMARIA</span>
                    </td>
                </tr>
             </table>

             <!-- FOOTER -->
              <div style="text-align: center; margin-top: 30px; font-size: 9px; color: #555;">
                <p style="font-weight: bold; color: #007f00;">CERVEZAS FINAS - FORMATO OFICIAL</p>
                <p>Fecha y hora de generación: ${new Date().toLocaleString()}</p>
            </div>

          </div>
        `,console.log("Waiting for images...");const m=e.querySelectorAll("img"),v=Array.from(m).map(o=>o.complete?Promise.resolve():new Promise(r=>{o.onload=r,o.onerror=()=>{console.warn("Failed img:",o.src),r()}}));await Promise.race([Promise.all(v),new Promise(o=>setTimeout(o,3e3))]),console.log("Rendering Canvas...");const h=await A(e,{scale:2,useCORS:!0,backgroundColor:"#ffffff",logging:!0,width:800,height:1123,windowWidth:1600}),p=new C("p","mm","a4"),_=h.toDataURL("image/jpeg",.9),E=p.internal.pageSize.getWidth(),u=p.internal.pageSize.getHeight();p.addImage(_,"JPEG",0,0,E,u);const s=`Alta_${(t.business_name||t.businessName||t.name||"Cliente").replace(/[^a-z0-9]/gi,"_")}_${Math.floor(Date.now()/1e3)}.pdf`;if(console.log("Saving PDF:",s),O.isNativePlatform())try{console.log("[PDF] Saving to native filesystem...");const o=p.output("datauristring").split(",")[1],r=await I.writeFile({path:s,data:o,directory:n.Cache});console.log("[PDF] File saved to cache:",r.uri);try{return await R.share({title:"Alta de Cliente PDF",text:`Formato de alta: ${t.business_name||t.name}`,url:r.uri,dialogTitle:"Guardar PDF en..."}),console.log("[PDF] PDF shared successfully"),document.body.removeChild(e),{success:!0,uri:r.uri,filename:s}}catch(w){return console.warn("[PDF] Share cancelled or failed:",w),document.body.removeChild(e),{success:!0,uri:r.uri,filename:s,shared:!1}}}catch(o){return console.error("[PDF] Error saving to filesystem:",o),document.body.removeChild(e),{success:!1,error:o.message}}else return p.save(s),document.body.removeChild(e),{success:!0,filename:s}}catch(e){return console.error("FATAL Error PDF:",e),document.getElementById("pdf-gen-container")&&document.body.removeChild(document.getElementById("pdf-gen-container")),{success:!1,error:e.message}}}export{x as E,z as g};
